<?php
include("db.php");

$msg = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $emp_id = $_POST['emp_id'];

    // Fetch employee details
    $stmt = $conn->prepare("SELECT * FROM employees WHERE emp_id = ?");
    $stmt->bind_param("i", $emp_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $employee = $result->fetch_assoc();

    // Fetch salary details for the employee
    $salary_stmt = $conn->prepare("SELECT * FROM salary WHERE emp_id = ?");
    $salary_stmt->bind_param("i", $emp_id);
    $salary_stmt->execute();
    $salary_result = $salary_stmt->get_result();
    $salary = $salary_result->fetch_assoc();

    if (!$employee || !$salary) {
        $msg = "No employee or salary record found!";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Generate Payslip</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f4f4f4;
            padding: 20px;
        }
        .form-container {
            max-width: 600px;
            background: white;
            padding: 30px;
            margin: auto;
            border-radius: 8px;
            box-shadow: 0 0 10px #ccc;
        }
        h2 {
            text-align: center;
        }
        input[type="number"] {
            width: 100%;
            padding: 10px;
            margin-top: 10px;
            margin-bottom: 20px;
            border: 1px solid #ccc;
            border-radius: 6px;
        }
        input[type="submit"] {
            background: #007bff;
            color: white;
            padding: 10px 15px;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            width: 100%;
        }
        .msg {
            text-align: center;
            color: red;
            font-weight: bold;
        }
        .payslip-container {
            max-width: 700px;
            margin: auto;
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px #ccc;
            margin-top: 30px;
        }
        .payslip-container h3 {
            text-align: center;
        }
        .payslip-container table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        .payslip-container table, .payslip-container th, .payslip-container td {
            border: 1px solid #ccc;
            padding: 10px;
            text-align: left;
        }
        .payslip-container th {
            background-color: #007bff;
            color: white;
        }
        .print-btn {
            background: #28a745;
            color: white;
            padding: 10px 15px;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            display: block;
            margin: auto;
            margin-top: 20px;
            width: 100%;
        }
    </style>
</head>
<body>

<div class="form-container">
    <h2>Generate Payslip</h2>
    <?php if ($msg): ?>
        <p class="msg"><?php echo $msg; ?></p>
    <?php endif; ?>

    <form method="POST" action="generate_payslip.php">
        <label>Employee ID:</label>
        <input type="number" name="emp_id" required>

        <input type="submit" value="Generate Payslip">
    </form>
</div>

<?php if (isset($employee) && isset($salary)): ?>
    <div class="payslip-container">
        <h3>Payslip for <?php echo htmlspecialchars($employee['name']); ?></h3>
        <table>
            <tr>
                <th>Employee ID</th>
                <td><?php echo $employee['emp_id']; ?></td>
            </tr>
            <tr>
                <th>Name</th>
                <td><?php echo $employee['name']; ?></td>
            </tr>
            <tr>
                <th>Designation</th>
                <td><?php echo $employee['designation']; ?></td>
            </tr>
            <tr>
                <th>Month</th>
                <td><?php echo $salary['month']; ?></td>
            </tr>
            <tr>
                <th>Year</th>
                <td><?php echo $salary['year']; ?></td>
            </tr>
            <tr>
                <th>Basic Salary</th>
                <td><?php echo number_format($salary['basic_salary'], 2); ?></td>
            </tr>
            <tr>
                <th>Allowances</th>
                <td><?php echo number_format($salary['allowances'], 2); ?></td>
            </tr>
            <tr>
                <th>Deductions</th>
                <td><?php echo number_format($salary['deductions'], 2); ?></td>
            </tr>
            <tr>
                <th>Net Salary</th>
                <td><?php echo number_format($salary['net_salary'], 2); ?></td>
            </tr>
        </table>

        <button class="print-btn" onclick="window.print()">Print Payslip</button>
    </div>
<?php endif; ?>

</body>
</html>
