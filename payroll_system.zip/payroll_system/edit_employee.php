<?php
// Ensure the employee ID is passed and is a valid number
if (isset($_GET['id']) && is_numeric($_GET['id'])) {
    $emp_id = $_GET['id'];

    // Now redirect to add_employee.php with the correct employee ID
    header("Location: add_employee.php?id=$emp_id");
    exit();  // Always call exit() after a header redirect to prevent further code execution
} else {
    // If the ID is not passed or is invalid, show an error message
    echo "❌ Invalid employee ID.";
}
