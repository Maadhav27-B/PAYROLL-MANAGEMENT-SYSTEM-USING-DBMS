<?php
// view_salaries.php
include 'db.php'; // Make sure this file connects to your DB

?>

<!DOCTYPE html>
<html>
<head>
    <title>View Salaries</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f6f8;
            padding: 20px;
        }
        h2 {
            color: #333;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            background-color: #fff;
            margin-top: 20px;
        }
        th, td {
            padding: 12px;
            text-align: center;
            border-bottom: 1px solid #ddd;
        }
        th {
            background-color: #007BFF;
            color: white;
        }
        tr:hover {
            background-color: #f1f1f1;
        }
    </style>
</head>
<body>

<h2>Salary Records</h2>

<table>
    <tr>
        <th>Employee Name</th>
        <th>Month</th>
        <th>Year</th>
        <th>Basic Salary</th>
        <th>Allowances</th>
        <th>Deductions</th>
        <th>Net Salary</th>
    </tr>

    <?php
    $sql = "SELECT s.*, e.name 
            FROM salary s 
            JOIN employees e ON s.emp_id = e.emp_id 
            ORDER BY s.year DESC, s.month DESC";
    $result = $conn->query($sql);

    if ($result && $result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            echo "<tr>
                    <td>" . htmlspecialchars($row['name']) . "</td>
                    <td>" . htmlspecialchars($row['month']) . "</td>
                    <td>" . htmlspecialchars($row['year']) . "</td>
                    <td>" . htmlspecialchars($row['basic_salary']) . "</td>
                    <td>" . htmlspecialchars($row['allowances']) . "</td>
                    <td>" . htmlspecialchars($row['deductions']) . "</td>
                    <td>" . htmlspecialchars($row['net_salary']) . "</td>
                  </tr>";
        }
    } else {
        echo "<tr><td colspan='7'>No salary records found.</td></tr>";
    }

    $conn->close();
    ?>
</table>

</body>
</html>
