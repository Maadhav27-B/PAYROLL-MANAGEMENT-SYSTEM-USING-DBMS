<?php
include 'db.php';
?>

<!DOCTYPE html>
<html>
<head>
    <title>View Attendance</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f0f2f5;
            margin: 0;
            padding: 0;
        }

        .container {
            max-width: 900px;
            margin: 50px auto;
            background: #ffffff;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 0 15px rgba(0,0,0,0.1);
        }

        h2 {
            text-align: center;
            color: #333333;
            margin-bottom: 20px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        th, td {
            padding: 12px 15px;
            border-bottom: 1px solid #ddd;
            text-align: center;
        }

        th {
            background-color: #007bff;
            color: white;
        }

        tr:hover {
            background-color: #f1f1f1;
        }

        .status-present { color: green; font-weight: bold; }
        .status-absent { color: red; font-weight: bold; }
        .status-leave { color: orange; font-weight: bold; }
    </style>
</head>
<body>

<div class="container">
    <h2>Employee Attendance Records</h2>
    <table>
        <thead>
            <tr>
                <th>Employee Name</th>
                <th>Date</th>
                <th>Status</th>
            </tr>
        </thead>
        <tbody>
        <?php
        $sql = "SELECT a.date, a.status, e.name 
                FROM attendance a 
                JOIN employees e ON a.emp_id = e.emp_id 
                ORDER BY a.date DESC";

        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $statusClass = strtolower($row['status']);
                echo "<tr>
                        <td>{$row['name']}</td>
                        <td>{$row['date']}</td>
                        <td class='status-{$statusClass}'>{$row['status']}</td>
                      </tr>";
            }
        } else {
            echo "<tr><td colspan='3'>No attendance records found.</td></tr>";
        }
        ?>
        </tbody>
    </table>
</div>

</body>
</html>
