<?php
session_start();
require 'db.php';

// Ensure only admin can access
if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit();
}

$username = $_SESSION['username'];

// Fetch quick stats (optional)
$employeeCount = $conn->query("SELECT COUNT(*) AS total FROM employees")->fetch_assoc()['total'];
$attendanceCount = $conn->query("SELECT COUNT(*) AS total FROM attendance")->fetch_assoc()['total'];
$salaryCount = $conn->query("SELECT COUNT(*) AS total FROM salary")->fetch_assoc()['total'];
?>

<!DOCTYPE html>
<html>
<head>
    <title>Admin Dashboard - Payroll System</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f4f4f4;
            margin: 0;
            padding: 0;
        }

        .header {
            background: #2c3e50;
            color: white;
            padding: 20px;
            text-align: center;
        }

        .container {
            padding: 30px;
        }

        .card {
            background: white;
            border-radius: 8px;
            padding: 20px;
            margin: 20px 0;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }

        .nav {
            display: flex;
            flex-wrap: wrap;
            gap: 20px;
        }

        .nav a {
            flex: 1 1 200px;
            padding: 15px;
            text-align: center;
            background: #3498db;
            color: white;
            border-radius: 6px;
            text-decoration: none;
            font-weight: bold;
            transition: background 0.3s ease;
        }

        .nav a:hover {
            background: #2980b9;
        }

        .logout {
            text-align: right;
            margin-top: -50px;
            margin-right: 30px;
        }

        .stats {
            display: flex;
            gap: 20px;
        }

        .stat {
            flex: 1;
            background: #27ae60;
            color: white;
            padding: 20px;
            border-radius: 8px;
            text-align: center;
        }

        .stat h2 {
            margin: 0;
        }

        .stat p {
            margin: 5px 0 0;
        }
    </style>
</head>
<body>

    <div class="header">
        <h1>Admin Dashboard - Payroll System</h1>
        <div class="logout">
            Logged in as: <strong><?php echo htmlspecialchars($username); ?></strong> |
            <a href="logout.php" style="color: #f1c40f;">Logout</a>
        </div>
    </div>

    <div class="container">

        <div class="stats">
            <div class="stat">
                <h2><?php echo $employeeCount; ?></h2>
                <p>Total Employees</p>
            </div>
            <div class="stat">
                <h2><?php echo $attendanceCount; ?></h2>
                <p>Total Attendance Records</p>
            </div>
            <div class="stat">
                <h2><?php echo $salaryCount; ?></h2>
                <p>Salary Processed</p>
            </div>
        </div>

        <div class="card">
            <h2>Admin Actions</h2>
            <div class="nav">
                <a href="add_employee.php">➕ Add Employee</a>
                <a href="view_employees.php">👥 View Employees</a>
                <a href="add_attendance.php">📅 Add Attendance</a>
                <a href="view_attendance.php">📋 View Attendance</a>
                <a href="add_salary.php">💰 Add Salary</a>
                <a href="view_salaries.php">📊 View Salaries</a>
                <a href="generate_payslip.php">📄 Generate Payslips</a>
            </div>
        </div>

    </div>

</body>
</html>
