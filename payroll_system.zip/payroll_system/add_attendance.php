<?php
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

include("db.php"); // Make sure this file connects to your database

// Fetch all employees for dropdown
$query = "SELECT emp_id, name FROM employees";
$result = $conn->query($query);

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $emp_id = $_POST['emp_id'];
    $date = $_POST['date'];
    $status = $_POST['status'];

    // Insert attendance data
    $stmt = $conn->prepare("INSERT INTO attendance (emp_id, date, status) VALUES (?, ?, ?)");
    $stmt->bind_param("iss", $emp_id, $date, $status);
    
    if ($stmt->execute()) {
        echo "Attendance added successfully.";
    } else {
        echo "Error adding attendance: " . $stmt->error;
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Add Attendance - Payroll System</title>
    <style>
        body {
            font-family: Arial;
            background: #f5f5f5;
            padding: 20px;
        }
        .form-container {
            max-width: 600px;
            margin: auto;
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 0 10px #ccc;
        }
        h1 {
            text-align: center;
        }
        label {
            font-weight: bold;
            margin-top: 10px;
        }
        select, input[type="date"], input[type="submit"] {
            width: 100%;
            padding: 8px;
            margin-top: 5px;
            margin-bottom: 15px;
            border-radius: 5px;
            border: 1px solid #ccc;
        }
        input[type="submit"] {
            background-color: #007bff;
            color: white;
            border: none;
            cursor: pointer;
        }
        input[type="submit"]:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>

<div class="form-container">
    <h1>Add Attendance</h1>
    <form action="add_attendance.php" method="POST">
        <label for="emp_id">Select Employee</label>
        <select name="emp_id" required>
            <option value="">Select Employee</option>
            <?php while ($row = $result->fetch_assoc()) { ?>
                <option value="<?php echo $row['emp_id']; ?>"><?php echo $row['name']; ?></option>
            <?php } ?>
        </select>

        <label for="date">Date</label>
        <input type="date" name="date" required>

        <label for="status">Attendance Status</label>
        <select name="status" required>
            <option value="Present">Present</option>
            <option value="Absent">Absent</option>
            <option value="Leave">Leave</option>
        </select>

        <input type="submit" value="Add Attendance">
    </form>
</div>

</body>
</html>
