<?php
include 'db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $emp_id = $_POST['emp_id'];
    $month = $_POST['month'];
    $year = $_POST['year'];
    $basic_salary = $_POST['basic_salary'];
    $allowances = $_POST['allowances'];
    $deductions = $_POST['deductions'];

    $net_salary = $basic_salary + $allowances - $deductions;

    $stmt = $conn->prepare("INSERT INTO salary (emp_id, month, year, basic_salary, allowances, deductions, net_salary) VALUES (?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("issdddd", $emp_id, $month, $year, $basic_salary, $allowances, $deductions, $net_salary);

    if ($stmt->execute()) {
        echo "<script>alert('Salary added successfully'); window.location.href='dashboard.php';</script>";
    } else {
        echo "Error: " . $stmt->error;
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Add Salary</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f4f6f8;
            margin: 0;
            padding: 0;
        }
        .container {
            max-width: 550px;
            margin: 60px auto;
            background: #ffffff;
            padding: 30px 40px;
            border-radius: 10px;
            box-shadow: 0px 0px 15px rgba(0,0,0,0.1);
        }
        h2 {
            text-align: center;
            margin-bottom: 30px;
            color: #333333;
        }
        label {
            font-weight: bold;
            display: block;
            margin-top: 15px;
            color: #555;
        }
        input[type="text"], input[type="number"], select {
            width: 100%;
            padding: 10px;
            margin-top: 6px;
            border: 1px solid #ccc;
            border-radius: 6px;
            box-sizing: border-box;
        }
        input[type="submit"] {
            width: 100%;
            background-color: #007BFF;
            color: white;
            padding: 12px;
            margin-top: 25px;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            font-size: 16px;
        }
        input[type="submit"]:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>

<div class="container">
    <h2>Add Employee Salary</h2>
    <form method="post" action="">
        <label for="emp_id">Select Employee:</label>
        <select name="emp_id" required>
            <option value="">-- Select Employee --</option>
            <?php
            $result = $conn->query("SELECT emp_id, name FROM employees");
            while ($row = $result->fetch_assoc()) {
                echo "<option value='{$row['emp_id']}'>{$row['name']} (ID: {$row['emp_id']})</option>";
            }
            ?>
        </select>

        <label for="month">Month:</label>
        <input type="text" name="month" placeholder="e.g. January" required>

        <label for="year">Year:</label>
        <input type="number" name="year" placeholder="e.g. 2025" required>

        <label for="basic_salary">Basic Salary:</label>
        <input type="number" step="0.01" name="basic_salary" required>

        <label for="allowances">Allowances:</label>
        <input type="number" step="0.01" name="allowances" required>

        <label for="deductions">Deductions:</label>
        <input type="number" step="0.01" name="deductions" required>

        <input type="submit" value="Add Salary">
    </form>
</div>

</body>
</html>
