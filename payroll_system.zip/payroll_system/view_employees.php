<?php
// Include database connection
require_once 'db.php';

// Fetch employee data
$sql = "SELECT * FROM employees";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Employees</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }

        .container {
            width: 90%;
            margin: 20px auto;
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        h2 {
            text-align: center;
            margin-bottom: 20px;
        }

        .employee-table {
            width: 100%;
            border-collapse: collapse;
            margin: 10px 0;
        }

        .employee-table th, .employee-table td {
            padding: 10px;
            text-align: left;
            border: 1px solid #ddd;
        }

        .employee-table th {
            background-color: #4CAF50;
            color: white;
        }

        .employee-table tr:nth-child(even) {
            background-color: #f2f2f2;
        }

        .employee-table tr:hover {
            background-color: #ddd;
        }

        .employee-table a {
            color: #4CAF50;
            text-decoration: none;
        }

        .employee-table a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>

    <div class="container">
        <h2>Employee Details</h2>
        <table class="employee-table">
            <thead>
                <tr>
                    <th>Employee ID</th>
                    <th>Username</th>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Phone</th>
                    <th>Department</th>
                    <th>Designation</th>
                    <th>Join Date</th>
                    <th>Basic Salary</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php
                if ($result->num_rows > 0) {
                    // Loop through each row and display employee details
                    while ($employee = $result->fetch_assoc()) {
                        echo "<tr>";
                        echo "<td>" . $employee['emp_id'] . "</td>";
                        echo "<td>" . $employee['username'] . "</td>";
                        echo "<td>" . $employee['name'] . "</td>";
                        echo "<td>" . $employee['email'] . "</td>";
                        echo "<td>" . $employee['phone'] . "</td>";
                        echo "<td>" . $employee['department'] . "</td>";
                        echo "<td>" . $employee['designation'] . "</td>";
                        echo "<td>" . $employee['join_date'] . "</td>";
                        echo "<td>" . $employee['basic_salary'] . "</td>";
                        echo "<td>
                                <a href='edit_employee.php?emp_id=" . $employee['emp_id'] . "'>Edit</a> |
                                <a href='delete_employee.php?emp_id=" . $employee['emp_id'] . "' onclick='return confirm(\"Are you sure you want to delete this employee?\");'>Delete</a>
                              </td>";
                        echo "</tr>";
                    }
                } else {
                    echo "<tr><td colspan='10'>No employees found</td></tr>";
                }
                ?>
            </tbody>
        </table>
    </div>

</body>
</html>
