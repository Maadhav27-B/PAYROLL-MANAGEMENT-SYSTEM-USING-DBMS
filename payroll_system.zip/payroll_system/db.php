<?php
$servername = "localhost";  // usually 'localhost'
$username = "root";         // your MySQL username
$password = "";             // your MySQL password (default is often empty for localhost)
$dbname = "payroll_system"; // the database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Optional: uncomment to test connection
// echo "Connected successfully";
?>