<?php
// Start the session
session_start();

// Check if the user is logged in as admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header('Location: login.php');
    exit();
}

// Include the database connection
require 'db.php';

// Fetch the admin's username (or any other details you need)
$username = $_SESSION['username'];

// Query to get employee details
$query = "SELECT * FROM employees";
$result = $conn->query($query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - Payroll System</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f5f5f5;
            padding: 20px;
        }
        .navbar {
            background-color: #007bff;
            color: white;
            padding: 10px;
            text-align: center;
        }
        .navbar a {
            color: white;
            text-decoration: none;
            margin: 0 15px;
        }
        .container {
            padding: 20px;
        }
        .dashboard {
            display: flex;
            flex-wrap: wrap;
            gap: 20px;
        }
        .dashboard-item {
            background-color: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            width: 45%;
        }
        h2 {
            text-align: center;
        }
        .employee-list {
            list-style-type: none;
            padding: 0;
        }
        .employee-list li {
            padding: 8px;
            background-color: #f9f9f9;
            margin-bottom: 10px;
            border-radius: 5px;
        }
    </style>
</head>
<body>

<!-- Navbar -->
<div class="navbar">
    <a href="dashboard_admin.php">Home</a>
    <a href="add_employee.php">Add Employee</a>
    <a href="add_attendance.php">Add Attendance</a>
    <a href="add_salary.php">Add Salaries</a>
    <a href="logout.php">Logout</a>
</div>

<!-- Admin Dashboard -->
<div class="container">
    <h2>Welcome, Admin: <?php echo htmlspecialchars($username); ?></h2>
    
    <div class="dashboard">
        <!-- Employee List Section -->
        <div class="dashboard-item">
            <h3>Employee List</h3>
            <ul class="employee-list">
                <?php
                // Check if there are any employees in the database
                if ($result->num_rows > 0) {
                    // Display each employee's details
                    while ($employee = $result->fetch_assoc()) {
                        echo '<li>';
                        echo 'Name: ' . htmlspecialchars($employee['name']) . '<br>';
                        echo 'Email: ' . htmlspecialchars($employee['email']) . '<br>';
                        echo 'Department: ' . htmlspecialchars($employee['department']) . '<br>';
                        echo 'Designation: ' . htmlspecialchars($employee['designation']) . '<br>';
                        echo '<a href="edit_employee.php?emp_id=' . $employee['emp_id'] . '">Edit</a> | ';
                        echo '<a href="delete_employee.php?emp_id=' . $employee['emp_id'] . '">Delete</a>';
                        echo '</li>';
                    }
                } else {
                    echo '<li>No employees found.</li>';
                }
                ?>
            </ul>
        </div>
        
        <!-- Attendance Section -->
        <div class="dashboard-item">
            <h3>Add Attendance</h3>
            <a href="add_attendance.php">Add Attendance</a>
        </div>
        
        <!-- Salary Section -->
        <div class="dashboard-item">
            <h3>Add Salaries</h3>
            <a href="add_salary.php">Add Salaries</a>
        </div>
    </div>
</div>

</body>
</html>
