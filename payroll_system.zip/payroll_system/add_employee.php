<?php
include("db.php");

$msg = "";
$editMode = false;

// Default empty values
$emp_id = $username = $name = $email = $phone = $department = $designation = $join_date = $basic_salary = "";

// Check for edit mode
if (isset($_GET['id'])) {
    $editMode = true;
    $edit_id = $_GET['id'];

    // Fetch employee details
    $stmt = $conn->prepare("SELECT * FROM employees WHERE emp_id = ?");
    $stmt->bind_param("i", $edit_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 1) {
        $row = $result->fetch_assoc();
        $emp_id = $row['emp_id'];
        $username = $row['username'];
        $name = $row['name'];
        $email = $row['email'];
        $phone = $row['phone'];
        $department = $row['department'];
        $designation = $row['designation'];
        $join_date = $row['join_date'];
        $basic_salary = $row['basic_salary'];
    } else {
        $msg = "Employee not found.";
    }
}

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $emp_id = $_POST['emp_id'];
    $username = $_POST['username'];
    $name = $_POST['name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $department = $_POST['department'];
    $designation = $_POST['designation'];
    $join_date = $_POST['join_date'];
    $basic_salary = $_POST['basic_salary'];

    if ($editMode) {
        // Update existing employee
        $stmt = $conn->prepare("UPDATE employees SET username=?, name=?, email=?, phone=?, department=?, designation=?, join_date=?, basic_salary=? WHERE emp_id=?");
        $stmt->bind_param("sssssssdi", $username, $name, $email, $phone, $department, $designation, $join_date, $basic_salary, $emp_id);

        if ($stmt->execute()) {
            $msg = "Employee updated successfully!";
        } else {
            $msg = "Error: " . $stmt->error;
        }
    } else {
        // Insert new employee
        $stmt = $conn->prepare("INSERT INTO employees (emp_id, username, name, email, phone, department, designation, join_date, basic_salary) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("isssssssd", $emp_id, $username, $name, $email, $phone, $department, $designation, $join_date, $basic_salary);

        if ($stmt->execute()) {
            $msg = "Employee added successfully!";
            // Clear form
            $emp_id = $username = $name = $email = $phone = $department = $designation = $join_date = $basic_salary = "";
        } else {
            $msg = "Error: " . $stmt->error;
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title><?= $editMode ? "Edit Employee" : "Add Employee" ?></title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f4f4f4;
            padding: 20px;
        }
        .form-container {
            max-width: 600px;
            background: white;
            padding: 30px;
            margin: auto;
            border-radius: 8px;
            box-shadow: 0 0 10px #ccc;
        }
        h2 {
            text-align: center;
        }
        input[type="text"], input[type="email"], input[type="number"], input[type="date"], input[type="tel"] {
            width: 100%;
            padding: 10px;
            margin-top: 10px;
            margin-bottom: 20px;
            border: 1px solid #ccc;
            border-radius: 6px;
        }
        input[type="submit"] {
            background: #007bff;
            color: white;
            padding: 10px 15px;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            width: 100%;
        }
        .msg {
            text-align: center;
            color: green;
            font-weight: bold;
        }
    </style>
</head>
<body>

<div class="form-container">
    <h2><?= $editMode ? "Edit Employee" : "Add New Employee" ?></h2>
    <?php if ($msg): ?>
        <p class="msg"><?= $msg ?></p>
    <?php endif; ?>
    <form method="POST" action="">

        <label>Employee ID:</label>
        <input type="number" name="emp_id" value="<?= htmlspecialchars($emp_id) ?>" required <?= $editMode ? 'readonly' : '' ?>>

        <label>Username:</label>
        <input type="text" name="username" value="<?= htmlspecialchars($username) ?>" required>

        <label>Full Name:</label>
        <input type="text" name="name" value="<?= htmlspecialchars($name) ?>" required>

        <label>Email:</label>
        <input type="email" name="email" value="<?= htmlspecialchars($email) ?>" required>

        <label>Phone:</label>
        <input type="tel" name="phone" value="<?= htmlspecialchars($phone) ?>" required>

        <label>Department:</label>
        <input type="text" name="department" value="<?= htmlspecialchars($department) ?>" required>

        <label>Designation:</label>
        <input type="text" name="designation" value="<?= htmlspecialchars($designation) ?>" required>

        <label>Joining Date:</label>
        <input type="date" name="join_date" value="<?= htmlspecialchars($join_date) ?>" required>

        <label>Basic Salary:</label>
        <input type="number" step="0.01" name="basic_salary" value="<?= htmlspecialchars($basic_salary) ?>" required>

        <input type="submit" value="<?= $editMode ? "Update Employee" : "Add Employee" ?>">
    </form>
</div>

</body>
</html>
